package com.deloitte.amazonproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmazonProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
